# Shutterwise starter website

A responsive, static photography education website. It is designed as a low-cost foundation for an evergreen content + affiliate business.

## Included
- Responsive home page
- Six original beginner guides
- Search and topic filtering
- Expandable article content
- Affiliate disclosure placeholder
- No fake newsletter form or fake affiliate links

## Important: this does not earn money automatically
The site has no active affiliate account, ads, newsletter backend, analytics, hosting or domain. Revenue requires useful traffic, genuine recommendations, eligible affiliate partnerships and ongoing updates. There is no income guarantee.

## Publish for ₹0
1. Create a GitHub account with help from a parent/guardian if needed.
2. Create a public repository named `shutterwise`.
3. Upload `index.html`.
4. In repository Settings → Pages, choose deploy from the `main` branch and root folder.
5. GitHub Pages will provide a public website address.

A free static host such as Cloudflare Pages is another option. A custom domain costs extra and is not necessary to test the idea.

## Before monetizing
- Add original, genuinely useful articles and photographs.
- Only recommend products you have researched; disclose limitations and how you evaluated them.
- Apply to affiliate programs only after checking their current eligibility, age, country, traffic and payment rules. Since the site owner is under 18, a parent/guardian may need to own and manage any account and payment arrangement.
- Add a real privacy policy before collecting visitor information.
- Add analytics only with an appropriate privacy notice.
- Apply to an ad network only when the site has enough original content and meets that network's current requirements.

## Weekly maintenance (1–2 hours)
- 30 min: improve one existing guide using first-hand experience/research.
- 30 min: create one genuinely useful new article or photo example.
- 15 min: check links, mobile layout and page speed.
- 15 min: review traffic and note which questions visitors are asking.

## First 30 days
Week 1: Publish the site and ask a few photography beginners what they find confusing.
Week 2: Add two original guides answering those questions.
Week 3: Add a comparison page only after checking current models/prices from reliable sources.
Week 4: Review whether people are finding and using the content. Do not buy ads or paid tools yet.

## Editing
Open `index.html` in a text editor. Search for the sample guide text and replace it with your own original material. Keep affiliate disclosures visible wherever affiliate links appear.
